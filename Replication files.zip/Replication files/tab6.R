
# ------------------------------------------- #
# Sao Paulo Plan Phase -> EAI                 #
# ------------------------------------------- #

	# clear memory
	rm(list=ls())
	gc()
	
	# packages
	library(lfe)
	library(stargazer)
	library(scales)
	library(ggplot2)
	
	# database
	# epidemiological data and classification (phases of the Sao Paulo Plan)
	DF <- readRDS("database_v2_15ago2020.rds")
	DF <- DF[DF$id_regiao < 18,]
	#criate id de data-DRS
	DF$dd_id <- paste(DF$data, DF$id_regiao)
	
	summary(DF$internacoes_7d)
	
	
	# create classification dummies
	DF$cl2 <- ifelse(DF$classificacao==2, 1, 0)
	DF$cl3 <- ifelse(DF$classificacao==3, 1, 0)
	
	# estimate the effect of classification on the EAI
	m.tr <- felm(Tradables~cl2 + cl3 | data + id_regiao, data=DF)
	m.no <- felm(Nontradables~cl2 + cl3 | data + id_regiao, data=DF)
	m.to <- felm(Total~cl2 + cl3 | data + id_regiao, data=DF)
	
	m.au <- felm(Caminhoes~cl2 + cl3 | data + id_regiao, data=DF)
	m.ca <- felm(Automoveis~cl2 + cl3 | data + id_regiao, data=DF)
	
	sto <- summary(m.to)$coefficients
					
	
	# Identify IAE and accumulated deaths with 24 days of lag
	LA <- DF[,c("dd_id", "id_regiao", "data", "Total", "obitos", "pop")]
	LA$data <- LA$data + 12
	LA$dd_id <- paste(LA$data, LA$id_regiao)
	LA$Total_lag <- LA$Total
	LA$obitos_acum_lag <- (LA$obitos/LA$pop)*1000000
	
	DF <- merge(DF, LA[,c("dd_id","Total_lag","obitos_acum_lag")], by="dd_id", all.x=T)
	
	# calculate: average hospitalizations per capita (per day) in the last 7 days
	DF$internacoes_7d_pop <- ((DF$internacoes_7d/DF$pop)*1000000)/7
	
	md <- unique(DF$data)
	
	# identify accumulated deaths with 7 days of lag
LA <- DF[,c("dd_id", "id_regiao", "data", "obitos_pop")]
LA$data <- LA$data + 7
LA$dd_id <- paste(LA$data, LA$id_regiao)
LA$obitos_pop_lag7 <- LA$obitos_pop
DF <- merge(DF, LA[,c("dd_id","obitos_pop_lag7")], by="dd_id", all.x=T)
	

# convert to intervals: obitos_pop_lag7
DF$obitos_pop_lag7_g0 <- ifelse(DF$obitos_pop_lag7 < 100, 1, 0)
DF$obitos_pop_lag7_g1 <- ifelse(DF$obitos_pop_lag7 > 100 & DF$obitos_pop_lag7 < 200, 1, 0)
DF$obitos_pop_lag7_g2 <- ifelse(DF$obitos_pop_lag7 > 200 & DF$obitos_pop_lag7 < 300, 1, 0)
DF$obitos_pop_lag7_g3 <- ifelse(DF$obitos_pop_lag7 > 300 & DF$obitos_pop_lag7 < 400, 1, 0)
DF$obitos_pop_lag7_g4 <- ifelse(DF$obitos_pop_lag7 > 400 & DF$obitos_pop_lag7 < 500, 1, 0)
DF$obitos_pop_lag7_g5 <- ifelse(DF$obitos_pop_lag7 > 500 & DF$obitos_pop_lag7 < 600, 1, 0)
DF$obitos_pop_lag7_g6 <- ifelse(DF$obitos_pop_lag7 > 600 & DF$obitos_pop_lag7 < 700, 1, 0)
DF$obitos_pop_lag7_g7 <- ifelse(DF$obitos_pop_lag7 > 700, 1, 0)

# convert to intervals: obitos_pop_lag7
DF$obitos_acum_lag_g0 <- ifelse(DF$obitos_acum_lag < 100, DF$Total_lag, 0)
DF$obitos_acum_lag_g1 <- ifelse(DF$obitos_acum_lag > 100 & DF$obitos_acum_lag <= 200, DF$Total_lag, 0)
DF$obitos_acum_lag_g2 <- ifelse(DF$obitos_acum_lag > 200 & DF$obitos_acum_lag <= 300, DF$Total_lag, 0)
DF$obitos_acum_lag_g3 <- ifelse(DF$obitos_acum_lag > 300 & DF$obitos_acum_lag <= 400, DF$Total_lag, 0)
DF$obitos_acum_lag_g4 <- ifelse(DF$obitos_acum_lag > 400 & DF$obitos_acum_lag <= 500, DF$Total_lag, 0)
DF$obitos_acum_lag_g5 <- ifelse(DF$obitos_acum_lag > 500 & DF$obitos_acum_lag <= 600, DF$Total_lag, 0)
DF$obitos_acum_lag_g6 <- ifelse(DF$obitos_acum_lag > 600 & DF$obitos_acum_lag <= 700, DF$Total_lag, 0)
DF$obitos_acum_lag_g7 <- ifelse(DF$obitos_acum_lag > 700, DF$Total_lag, 0)

# regress 2

FF <- DF[DF$data>=as.Date("2020-05-29"),]
FF$log_internacoes_7d_pop <- log(FF$internacoes_7d_pop)


m1 <- lm(log_internacoes_7d_pop~obitos_pop_lag7_g1+obitos_pop_lag7_g2+obitos_pop_lag7_g3+
										obitos_pop_lag7_g4+obitos_pop_lag7_g5+obitos_pop_lag7_g6+obitos_pop_lag7_g7+
										Total_lag,
									data=FF)

m2 <- lm(log_internacoes_7d_pop~obitos_pop_lag7_g1+obitos_pop_lag7_g2+obitos_pop_lag7_g3+
										obitos_pop_lag7_g4+obitos_pop_lag7_g5+obitos_pop_lag7_g6+obitos_pop_lag7_g7+
										obitos_acum_lag_g0+obitos_acum_lag_g1+obitos_acum_lag_g2+obitos_acum_lag_g3+
										obitos_acum_lag_g4+obitos_acum_lag_g5,
									data=FF)

stargazer(m1, m2,
									type = "html",
										out="tab6.html",
										omit.stat=c("f", "ser", "adj.rsq","n"))






ss <- as.data.frame(summary(m2)$coefficients)

ss <- ss[9:14,]
ss$e <-ss$Estimate
ss$se <-ss$`Std. Error`

ss$u <- ss$e + 1.96*ss$`Std. Error`
ss$d <- ss$e - 1.96*ss$`Std. Error`

ss$g <- 1:6
ggplot() + 
	geom_point(aes(x=g, y=e), data=ss) +
	geom_errorbar(aes(x=g, ymin=d, ymax=u), data=ss, width=0) +
	geom_hline(yintercept = 0, colour="gray", width=0) +
	theme_bw() +
	theme(panel.grid = element_blank()) +
	labs(y="effect of: 1% EAI increase (-12 days) on hospitalizations", x= "pandemic stage - accumulated deaths per million") +
	scale_x_continuous(breaks = 1:6,
																				labels = c("0-100", "100-200","200-300",
																															"300-400","400-500","500-600")) +
	scale_y_continuous(labels = percent)
	

