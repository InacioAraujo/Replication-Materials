# ------------------------------------------- #
# converte dados dta                          #
# ------------------------------------------- #

# clear memory
rm(list=ls())
gc()

# packages
#install.packages("readstata13") 
library(readstata13)

DF <- read.dta13("database_v2_15ago2020.dta")
DF$drs_data <- paste(DF$id_regiao, DF$data)

saveRDS(DF, "database_v2_15ago2020.rds")