
# ------------------------------------------- #
# Sao Paulo Plan Phase -> EAI                 #
# ------------------------------------------- #

# clear memory
rm(list=ls())
gc()

# packages
# install.packages("lfe") 
# install.packages("stargazer") 
# install.packages("ggplot2") 
library(lfe)
library(stargazer)
library(ggplot2)

# database
# epidemiological data and classification (phases of the Sao Paulo Plan)
DF <- readRDS("database_v2_15ago2020.rds")
DF <- DF[DF$id_regiao < 18,]
# create id: data-DRS
DF$dd_id <- paste(DF$data, DF$id_regiao)


# create classification dummies
DF$cl2 <- ifelse(DF$classificacao==2, 1, 0)
DF$cl3 <- ifelse(DF$classificacao==3, 1, 0)

# estimate the effect of classification on the EAI
m.tr <- felm(Tradables~cl2 + cl3 | data + id_regiao, data=DF)
m.no <- felm(Nontradables~cl2 + cl3 | data + id_regiao, data=DF)
m.to <- felm(Total~cl2 + cl3 | data + id_regiao, data=DF)

b2 <- m.to$coefficients[1]
b3 <- m.to$coefficients[2]


# weghts	
WW <- read.csv("pesos.csv")
DF$DRS <- DF$id_regiao
DF <- merge(DF, WW, by="DRS", all.x=T)


# base: contrafactual
CC<-DF
# EAI: contrafactual
CC$Total <- ifelse(DF$cl2%in%1, DF$Total - b2,
													ifelse(DF$cl3%in%1, DF$Total - b3,
																				DF$Total))

# EAI: State of Sao Paulo (components)
CC$IAE_W <- CC$Total*CC$peso
DF$IAE_W <- DF$Total*DF$peso

# EAI: State of Sao Paulo
CC$IAE_SP <- ave(CC$IAE_W, CC$data, FUN=sum)
DF$IAE_SP <- ave(DF$IAE_W, DF$data, FUN=sum)

# daily data
DC <- CC[!duplicated(CC$data),]
DO <- DF[!duplicated(DF$data),]
	
# figures	
ggplot() +
 geom_line(aes(x=data, y = IAE_SP, colour = "c"), data = DC) +
	geom_line(aes(x=data, y = IAE_SP, colour = "o"), data = DO) +
	theme_bw() +
	scale_colour_manual(labels = c("o" = "A) observed scenario   ", "c"="B) counterfactual scenario   "),
																					values = c("o" = "gray20", "c"="red"),
																					limits = c("o", "c"),
																					name = "EAI Total - State of SP:    ") +
	labs(y="EAI Total", x = "date") +
	scale_x_date(breaks = as.Date(c("2020-05-01","2020-06-01","2020-07-01","2020-08-01")),
														date_labels = c("May", "June", "July", "Ausgust")) +
	scale_y_continuous(breaks = seq(0,100,10)) +
	theme(panel.grid.minor = element_blank(),
							panel.grid.major = element_line(size=0.25),
							legend.position = "top") +
	coord_cartesian(ylim = c(50,100))
ggsave("fig5.eps", w=7, h=5)
ggsave("fig5.png", w=7, h=5)
