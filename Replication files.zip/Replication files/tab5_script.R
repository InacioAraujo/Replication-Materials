
# ------------------------------------------- #
# Sao Paulo Plan Phase -> EAI                 #
# ------------------------------------------- #

# clear memory
rm(list=ls())
gc()

# packages
# install.packages("lfe") 
# install.packages("stargazer") 
# install.packages("scales") 
# install.packages("ggplot2") 
library(lfe)
library(stargazer)
library(scales)
library(ggplot2)

# database
# epidemiological data and classification (phases of the Sao Paulo Plan)
DF <- readRDS("database_v2_15ago2020.rds")
DF <- DF[DF$id_regiao < 18,]
# create id: data-DRS
DF$dd_id <- paste(DF$data, DF$id_regiao)


# create classification dummies
DF$cl2 <- ifelse(DF$classificacao==2, 1, 0)
DF$cl3 <- ifelse(DF$classificacao==3, 1, 0)

DF$Caminhoes<- DF$Caminhoes*100
DF$Automoveis<- DF$Automoveis*100

# estimate the effect of classification on the EAI
m.tr <- felm(Tradables~cl2 + cl3 | data + id_regiao, data=DF)
m.no <- felm(Nontradables~cl2 + cl3 | data + id_regiao, data=DF)
m.to <- felm(Total~cl2 + cl3 | data + id_regiao, data=DF)

m.au <- felm(Caminhoes~cl2 + cl3 | data + id_regiao, data=DF)
m.ca <- felm(Automoveis~cl2 + cl3 | data + id_regiao, data=DF)

sto <- summary(m.to)$coefficients

stargazer(m.tr,m.no,m.to,m.au,m.ca,
									type = "html",
										out="tab5.html",
										covariate.labels = c("Fase 2",
																															"Fase 3"),
										dep.var.caption = "IAE",
										dep.var.labels= c("tradables",
																												"non-tradables",
																												"total",
																												"freight",
																												"passengers"),
										add.lines = list(c("Efeito fixo: data", rep("sim",5)),
                           c("Efeito fixo: DRS", rep("sim",5)),
																											c("Obs.:", c(m.tr$N, m.no$N, m.to$N,m.au$N, m.ca$N))),
										omit.stat=c("f", "ser", "adj.rsq","n"))
