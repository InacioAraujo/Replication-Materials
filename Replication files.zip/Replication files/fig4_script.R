
# ------------------------------------------- #
# Sao Paulo Plan Phase -> EAI                 #
# ------------------------------------------- #

# clear memory
rm(list=ls())
gc()

# packages
# install.packages("lfe") 
# install.packages("stargazer") 
# install.packages("ggplot2") 
library(lfe)
library(stargazer)
library(ggplot2)

# database
# epidemiological data and classification (phases of the Sao Paulo Plan)
DF <- readRDS("database_v2_15ago2020.rds")
DF <- DF[DF$id_regiao < 18,]
DF <- DF[DF$data >= as.Date("2020-05-29"),]

DF$fase <- as.character(DF$classificacao)
DF$cl
DF$nome <- DF$nome_drs

DF$nome_drs <- gsub("01", "I -",DF$nome_drs)
DF$nome_drs <- gsub("02", "II -",DF$nome_drs)
DF$nome_drs <- gsub("03", "III -",DF$nome_drs)
DF$nome_drs <- gsub("04", "IV -",DF$nome_drs)
DF$nome_drs <- gsub("05", "V -",DF$nome_drs)
DF$nome_drs <- gsub("06", "VI -",DF$nome_drs)

DF$nome_drs <- gsub("07", "VII -",DF$nome_drs)
DF$nome_drs <- gsub("08", "VIII -",DF$nome_drs)
DF$nome_drs <- gsub("09", "IX -",DF$nome_drs)
DF$nome_drs <- gsub("10", "X -",DF$nome_drs)
DF$nome_drs <- gsub("11", "XI -",DF$nome_drs)
DF$nome_drs <- gsub("12", "XII -",DF$nome_drs)

DF$nome_drs <- gsub("13", "XIII -",DF$nome_drs)
DF$nome_drs <- gsub("14", "XIV -",DF$nome_drs)
DF$nome_drs <- gsub("15", "XV -",DF$nome_drs)
DF$nome_drs <- gsub("16", "XVI -",DF$nome_drs)
DF$nome_drs <- gsub("17", "XVII -",DF$nome_drs)

DF$nome <- as.factor(DF$nome)

mn <- DF$nome_drs[!duplicated(DF$nome_drs)]


ggplot() +
	geom_point(aes(x=data,y=nome,colour=fase),data=DF) +
	theme_bw() +
	scale_y_discrete(limits = rev(levels(DF$nome)),
																		labels = rev(mn)) +
	theme(legend.position = "top") +
	scale_colour_manual(values = c("1"="firebrick","2"="darkorange", "3"="gold",
																																"4"="forestgreen", "5"="royalblue"),
																					name = "Sao Paulo Plan Phase: ",
																					limits = c("1","2","3","4","5")) +
	labs(y = "DRS", x = "date")
ggsave("fig4.eps", w=6.6,h=5.5)
ggsave("fig4.png", w=6.6,h=5.5)

