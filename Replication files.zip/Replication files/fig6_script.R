
# ------------------------------------------- #
# Sao Paulo Plan Phase -> EAI                 #
# ------------------------------------------- #

# clear memory
rm(list=ls())
gc()

# packages
# install.packages("lfe") 
# install.packages("stargazer") 
# install.packages("ggplot2") 
library(lfe)
library(stargazer)
library(ggplot2)

# database
# epidemiological data and classification (phases of the Sao Paulo Plan)
DF <- readRDS("database_v2_15ago2020.rds")
DF <- DF[DF$id_regiao < 18,]
#DF <- DF[DF$data >= as.Date("2020-05-29"),]

DF$vol <- 0
DF$tot7 <- 0

md <- unique(DF$data)
mr <- unique(DF$id_regiao)


for(i in 7:103){#i<-7
#	for(j in 1:17){# j <- 1
		TD <- DF[DF$data>=md[i-6] & DF$data<=md[i],]
	 mv <- sd(TD$Total)
	 mt <- mean(TD$Total)
	 DF$vol[DF$data==md[i]] <- mv
	 DF$tot7[DF$data==md[i]] <- mt
}

DD <- DF[!duplicated(DF$data),]
DD <- DD[(DD$vol!=0),]

DD$dp_tot <- DD$vol/DD$tot7

ggplot() +
	geom_point(aes(x=data, y=dp_tot),data=DD, size=1) +
	theme_bw() +
 geom_vline(aes(colour="i", xintercept = as.Date("2020-06-01")), linetype = 2) +
 labs(x="date", y="coefficient of variation\n(EAI Total)") +
 scale_colour_manual(values = c("i"="red"),
 																				labels = c ("i"="Beginning of Sao Paulo Plan"),
 																				name = "") +
	theme(legend.position = "top",
							panel.grid = element_line(size=0.25)) +
	coord_cartesian(ylim = c(0,0.08))
ggsave("fig6.eps", w=6,h=4)
ggsave("fig6.png", w=6,h=4)
