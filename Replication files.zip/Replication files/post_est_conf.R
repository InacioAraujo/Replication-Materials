
# ------------------------------------------- #
# Sao Paulo Plan Phase -> EAI                 #
# ------------------------------------------- #

# clear memory
rm(list=ls())
gc()

# packages
library(lfe)
library(stargazer)
library(scales)
library(ggplot2)




# database
# epidemiological data and classification (phases of the Sao Paulo Plan)
DF <- readRDS("database_v2_15ago2020.rds")
DF <- DF[DF$id_regiao < 18,]
#crias id de data-DRS
DF$dd_id <- paste(DF$data, DF$id_regiao)

# create classification dummies
DF$cl2 <- ifelse(DF$classificacao==2, 1, 0)
DF$cl3 <- ifelse(DF$classificacao==3, 1, 0)

# IM
DF$IM_cam <- DF$Caminhoes*100
DF$IM_aut <- DF$Automoveis*100

# estimate the effect of classification on the EAI
m.to <- felm(Total~cl2 + cl3 | data + id_regiao, data=DF)
s.to <- summary(m.to)$coefficients

# Identify IAE and accumulated deaths with 24 days of lag
	LA <- DF[,c("dd_id", "id_regiao", "data", "Total", "obitos", "pop")]
	LA$data <- LA$data + 12
	LA$dd_id <- paste(LA$data, LA$id_regiao)
	LA$Total_lag <- LA$Total
	LA$obitos_acum_lag <- (LA$obitos/LA$pop)*1000000
	
	DF <- merge(DF, LA[,c("dd_id","Total_lag","obitos_acum_lag")], by="dd_id", all.x=T)

# calculate: average hospitalizations per capita (per day) in the last 7 days
	DF$internacoes_7d_pop <- ((DF$internacoes_7d/DF$pop)*1000000)/7

# identify accumulated deaths with 7 days of lag
LA <- DF[,c("dd_id", "id_regiao", "data", "obitos_pop")]
LA$data <- LA$data + 7
LA$dd_id <- paste(LA$data, LA$id_regiao)
LA$obitos_pop_lag7 <- LA$obitos_pop
DF <- merge(DF, LA[,c("dd_id","obitos_pop_lag7")], by="dd_id", all.x=T)


# convert to intervals: obitos_pop_lag7
DF$obitos_pop_lag7_g0 <- ifelse(DF$obitos_pop_lag7 < 100, 1, 0)
DF$obitos_pop_lag7_g1 <- ifelse(DF$obitos_pop_lag7 > 100 & DF$obitos_pop_lag7 < 200, 1, 0)
DF$obitos_pop_lag7_g2 <- ifelse(DF$obitos_pop_lag7 > 200 & DF$obitos_pop_lag7 < 300, 1, 0)
DF$obitos_pop_lag7_g3 <- ifelse(DF$obitos_pop_lag7 > 300 & DF$obitos_pop_lag7 < 400, 1, 0)
DF$obitos_pop_lag7_g4 <- ifelse(DF$obitos_pop_lag7 > 400 & DF$obitos_pop_lag7 < 500, 1, 0)
DF$obitos_pop_lag7_g5 <- ifelse(DF$obitos_pop_lag7 > 500 & DF$obitos_pop_lag7 < 600, 1, 0)
DF$obitos_pop_lag7_g6 <- ifelse(DF$obitos_pop_lag7 > 600 & DF$obitos_pop_lag7 < 700, 1, 0)
DF$obitos_pop_lag7_g7 <- ifelse(DF$obitos_pop_lag7 > 700, 1, 0)

# convert to intervals: obitos_pop_lag7
DF$obitos_acum_lag_g0 <- ifelse(DF$obitos_acum_lag < 100, DF$Total_lag, 0)
DF$obitos_acum_lag_g1 <- ifelse(DF$obitos_acum_lag > 100 & DF$obitos_acum_lag <= 200, DF$Total_lag, 0)
DF$obitos_acum_lag_g2 <- ifelse(DF$obitos_acum_lag > 200 & DF$obitos_acum_lag <= 300, DF$Total_lag, 0)
DF$obitos_acum_lag_g3 <- ifelse(DF$obitos_acum_lag > 300 & DF$obitos_acum_lag <= 400, DF$Total_lag, 0)
DF$obitos_acum_lag_g4 <- ifelse(DF$obitos_acum_lag > 400 & DF$obitos_acum_lag <= 500, DF$Total_lag, 0)
DF$obitos_acum_lag_g5 <- ifelse(DF$obitos_acum_lag > 500 & DF$obitos_acum_lag <= 600, DF$Total_lag, 0)
DF$obitos_acum_lag_g6 <- ifelse(DF$obitos_acum_lag > 600 & DF$obitos_acum_lag <= 700, DF$Total_lag, 0)
DF$obitos_acum_lag_g7 <- ifelse(DF$obitos_acum_lag > 700, DF$Total_lag, 0)

# regress 2

FF <- DF[DF$data>=as.Date("2020-05-29"),]
FF$log_internacoes_7d_pop <- log(FF$internacoes_7d_pop)

m1 <- lm(log_internacoes_7d_pop~obitos_pop_lag7_g1+obitos_pop_lag7_g2+obitos_pop_lag7_g3+
										obitos_pop_lag7_g4+obitos_pop_lag7_g5+obitos_pop_lag7_g6+obitos_pop_lag7_g7+
										Total_lag,
									data=FF)

m2 <- lm(log_internacoes_7d_pop~obitos_pop_lag7_g1+obitos_pop_lag7_g2+obitos_pop_lag7_g3+
										obitos_pop_lag7_g4+obitos_pop_lag7_g5+obitos_pop_lag7_g6+obitos_pop_lag7_g7+
										obitos_acum_lag_g0+obitos_acum_lag_g1+obitos_acum_lag_g2+obitos_acum_lag_g3+
										obitos_acum_lag_g4+obitos_acum_lag_g5,
									data=FF)

s1 <- summary(m1)$coefficients
s2 <- summary(m2)$coefficients


EF <- data.frame(matrix(nrow = 1000))
EF$ef1 <- 0
EF$ef2 <- 0
for(i in 1:1000){

# central case
	CC <- DF
	DF0 <- DF

	b2 <- rnorm(1, s.to[1,1], s.to[1,2])
	b3 <- rnorm(1, s.to[2,1],s.to[2,2])
	
	
	s1.1 <- rnorm(1, s1[9,1],s1[9,2])

	s2.0 <- rnorm(1, s2[9,1],s2[9,1])
	s2.1 <- rnorm(1, s2[10,1],s2[10,1])
	s2.2 <- rnorm(1, s2[11,1],s2[11,1])
	s2.3 <- rnorm(1, s2[12,1],s2[12,1])
	s2.4 <- rnorm(1, s2[13,1],s2[13,1])
	s2.5 <- rnorm(1, s2[14,1],s2[14,1])
	
	
	CC$Total <- ifelse(DF$cl2%in%1, DF$Total - b2,
													ifelse(DF$cl3%in%1, DF$Total - b3,
																				DF$Total))


 
	# Effect
	
	# identify IAE with n days of lag
 LA <- CC[,c("dd_id", "id_regiao", "data", "Total")]
 LA$data <- LA$data + 12
 LA$dd_id <- paste(LA$data, LA$id_regiao)
 LA$Total_lag2 <- LA$Total
 CC <- merge(CC, LA[,c("dd_id","Total_lag2")], by="dd_id", all.x=T)
 CC$Total_lag <- CC$Total_lag2
 
 CC$obitos_acum_lag_g0 <- ifelse(CC$obitos_acum_lag < 100, CC$Total_lag, 0)
 CC$obitos_acum_lag_g1 <- ifelse(CC$obitos_acum_lag > 100 & CC$obitos_acum_lag <= 200, CC$Total_lag, 0)
 CC$obitos_acum_lag_g2 <- ifelse(CC$obitos_acum_lag > 200 & CC$obitos_acum_lag <= 300, CC$Total_lag, 0)
 CC$obitos_acum_lag_g3 <- ifelse(CC$obitos_acum_lag > 300 & CC$obitos_acum_lag <= 400, CC$Total_lag, 0)
 CC$obitos_acum_lag_g4 <- ifelse(CC$obitos_acum_lag > 400 & CC$obitos_acum_lag <= 500, CC$Total_lag, 0)
 CC$obitos_acum_lag_g5 <- ifelse(CC$obitos_acum_lag > 500 & CC$obitos_acum_lag <= 600, CC$Total_lag, 0)
 CC$obitos_acum_lag_g6 <- ifelse(CC$obitos_acum_lag > 600 & CC$obitos_acum_lag <= 700, CC$Total_lag, 0)
 CC$obitos_acum_lag_g7 <- ifelse(CC$obitos_acum_lag > 700, CC$Total_lag, 0)



 # Create: predicted hospitalizations 
 DF0$int_0_pc_m1 <- with(DF0, Total_lag*s1.1+
                                 obitos_pop_lag7_g1*s1[2,1]+
 																												    obitos_pop_lag7_g2*s1[3,1]+
 																												    obitos_pop_lag7_g3*s1[4,1]+
 																																obitos_pop_lag7_g4*s1[5,1]+
 																												    obitos_pop_lag7_g5*s1[6,1]+
 																												    obitos_pop_lag7_g6*s1[7,1]+
 																												    obitos_pop_lag7_g7*s1[8,1])

 DF0$int_0_pc_m2 <- with(DF0,
 																											obitos_acum_lag_g0*s2.0+
 																											obitos_acum_lag_g1*s2.1+
 																									  obitos_acum_lag_g2*s2.2+
 																											obitos_acum_lag_g3*s2.3+
 																									  obitos_acum_lag_g4*s2.4+
 																											obitos_acum_lag_g5*s2.5+
 																									  obitos_pop_lag7_g1*s2[2,1]+
 																											obitos_pop_lag7_g2*s2[3,1]+
 																											obitos_pop_lag7_g3*s2[4,1]+
										                  obitos_pop_lag7_g4*s2[5,1]+
 																											obitos_pop_lag7_g5*s2[6,1]+
 																											obitos_pop_lag7_g6*s2[7,1]+
 																											obitos_pop_lag7_g7*s2[8,1])

 CC$int_1_pc_m1 <- with(CC, Total_lag*s1.1+
                                 obitos_pop_lag7_g1*s1[2,1]+
 																												    obitos_pop_lag7_g2*s1[3,1]+
 																												    obitos_pop_lag7_g3*s1[4,1]+
 																																obitos_pop_lag7_g4*s1[5,1]+
 																												    obitos_pop_lag7_g5*s1[6,1]+
 																												    obitos_pop_lag7_g6*s1[7,1]+
 																												    obitos_pop_lag7_g7*s1[8,1])

 CC$int_1_pc_m2 <- with(CC,
 																											obitos_acum_lag_g0*s2.0+
 																											obitos_acum_lag_g1*s2.1+
 																									  obitos_acum_lag_g2*s2.2+
 																											obitos_acum_lag_g3*s2.3+
 																									  obitos_acum_lag_g4*s2.4+
 																											obitos_acum_lag_g5*s2.5+
 																									  obitos_pop_lag7_g1*s2[2,1]+
 																											obitos_pop_lag7_g2*s2[3,1]+
 																											obitos_pop_lag7_g3*s2[4,1]+
										                  obitos_pop_lag7_g4*s2[5,1]+
 																											obitos_pop_lag7_g5*s2[6,1]+
 																											obitos_pop_lag7_g6*s2[7,1]+
 																											obitos_pop_lag7_g7*s2[8,1])
 
 DF00 <- DF0[DF0$data>=as.Date("2020-05-29"),]
 CC00 <- CC[CC$data>=as.Date("2020-05-29"),]
 
 
 DF00$int_0_m1 <- exp(DF00$int_0_pc_m1)*DF00$pop/1000000
 CC00$int_1_m1 <- exp(CC00$int_1_pc_m1)*CC00$pop/1000000
 
 DF00$int_0_m2 <- exp(DF00$int_0_pc_m2)*DF00$pop/1000000
 CC00$int_1_m2 <- exp(CC00$int_1_pc_m2)*CC00$pop/1000000
 
 
 
 #summary(CC00$int_1_pc_m1)
 
 # The observed number of COVID-19 hospitalizations in the State of S�o Paulo between May 29 up until August 1st was of:
 dd <- sum(FF$internacoes[FF$data>=as.Date("2020-05-29")])
 
 
 EF$ef1[i] <- (sum(CC00$int_1_m1) - sum(DF00$int_0_m1))/sum(DF00$int_0_m1)
 EF$ef2[i] <- (sum(CC00$int_1_m2) - sum(DF00$int_0_m2))/sum(DF00$int_0_m2)
 
 cat(i, " ")
}
lb1 <- quantile(EF$ef1, 0.025)
ub1 <- quantile(EF$ef1, 0.975)

lb2 <- quantile(EF$ef2, 0.025)
ub2 <- quantile(EF$ef2, 0.975)

